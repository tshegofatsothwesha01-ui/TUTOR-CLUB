(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const state = {csrf: '', email: '', demo: false, learners: [], payments: [], outstanding: [], currentLearnerId: '', view: 'overview', paymentTab: 'transactions'};
  const loginPage = $('#loginPage');
  const adminFrame = $('#adminFrame');
  const drawerOverlay = $('#detailOverlay');
  const drawerContent = $('#drawerContent');
  let toastTimer = null;

  const formatRand = (cents) => `R${(Number(cents || 0) / 100).toLocaleString('en-ZA', {minimumFractionDigits: 0, maximumFractionDigits: 2})}`;
  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const statusClass = (value) => `status-${String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  const statusPill = (value) => `<span class="status-pill ${statusClass(value)}">${escapeHtml(value || '—')}</span>`;
  const dateShort = (value) => {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : date.toLocaleDateString('en-ZA', {day: 'numeric', month: 'short', year: 'numeric'});
  };
  const dateTime = (value) => {
    if (!value) return '—';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '—' : `${date.toLocaleDateString('en-ZA', {day: 'numeric', month: 'short', year: 'numeric'})} · ${date.toLocaleTimeString('en-ZA', {hour: '2-digit', minute: '2-digit'})}`;
  };

  async function api(url, options = {}) {
    const headers = new Headers(options.headers || {});
    if (options.body && !headers.has('Content-Type')) headers.set('Content-Type', 'application/json');
    if (options.method && options.method !== 'GET' && state.csrf) headers.set('X-CSRF-Token', state.csrf);
    const response = await fetch(url, {...options, headers, credentials: 'same-origin', cache: 'no-store'});
    const data = response.status === 204 ? {} : await response.json().catch(() => ({}));
    if (response.status === 401 && url !== '/api/admin/login') {
      showLogin();
      throw new Error('Your session expired. Please sign in again.');
    }
    if (!response.ok) throw new Error(data.error || 'The request could not be completed.');
    return data;
  }

  function showLogin() {
    state.csrf = '';
    loginPage.hidden = false;
    adminFrame.hidden = true;
    drawerOverlay.hidden = true;
    fetch('/api/config', {cache: 'no-store'}).then((r) => r.json()).then((config) => {
      if (!config.demo_mode) return;
      $('#demoCredentials').hidden = false;
      $('#demoEmail').textContent = `Email: ${config.demo_admin_email || 'admin@tutorclub.demo'}`;
      $('#demoPassword').textContent = `Password: ${config.demo_admin_password || 'TutorClubDemo!2026'}`;
    }).catch(() => {});
  }

  function showDashboard(session) {
    state.csrf = session.csrf_token;
    state.email = session.email;
    state.demo = Boolean(session.demo_mode);
    loginPage.hidden = true;
    adminFrame.hidden = false;
    $('#adminDemoBadge').hidden = !state.demo;
    $('#adminAvatar').textContent = (state.email.split('@')[0] || 'TC').slice(0, 2).toUpperCase();
    $('#todayDate').textContent = new Date().toLocaleDateString('en-ZA', {weekday: 'short', day: 'numeric', month: 'short'});
    refreshAll();
  }

  function toast(text, isError = false) {
    const node = $('#adminToast');
    node.textContent = text;
    node.style.background = isError ? '#8d3f35' : '#10231f';
    node.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = window.setTimeout(() => node.classList.remove('show'), 2400);
  }

  async function refreshAll() {
    try {
      const [summary, learnerData, paymentData] = await Promise.all([
        api('/api/admin/summary'), api('/api/admin/learners'), api('/api/admin/payments')
      ]);
      state.learners = learnerData.learners || [];
      state.payments = paymentData.payments || [];
      state.outstanding = paymentData.outstanding || [];
      renderSummary(summary);
      renderLearners();
      renderPaymentViews();
    } catch (error) {
      toast(error.message, true);
    }
  }

  function renderSummary(summary) {
    $('#statLearners').textContent = summary.total_learners ?? 0;
    $('#statActive').textContent = summary.active_learners ?? 0;
    $('#statPending').textContent = summary.pending_learners ?? 0;
    $('#statOutstanding').textContent = formatRand(summary.outstanding_cents);
    const recent = [...state.learners].slice(0, 6);
    $('#recentLearners').innerHTML = recent.length ? recent.map((learner) => `
      <tr class="clickable" data-learner="${escapeHtml(learner.id)}">
        <td class="cell-main">${escapeHtml(learner.learner_name)}<span class="cell-sub">${escapeHtml(learner.id)}</span></td>
        <td>${escapeHtml(learner.grade)}</td><td>${escapeHtml(learner.mode)}</td><td>${statusPill(learner.enrollment_status)}</td>
      </tr>`).join('') : '<tr><td colspan="4" class="admin-empty">No registrations yet. New learners will appear here.</td></tr>';
    const recentPayments = [...state.payments].slice(0, 6);
    $('#recentPayments').innerHTML = recentPayments.length ? recentPayments.map((payment) => `
      <tr class="clickable" data-learner="${escapeHtml(payment.learner_id)}">
        <td class="cell-main">${escapeHtml(payment.learner_name)}<span class="cell-sub">${dateShort(payment.created_at)}</span></td>
        <td>${escapeHtml(payment.method)}</td><td class="cell-main">${formatRand(payment.amount_cents)}</td>
      </tr>`).join('') : '<tr><td colspan="3" class="admin-empty">No payments have been recorded yet.</td></tr>';
  }

  function renderLearners() {
    const query = ($('#learnerSearch')?.value || '').trim().toLowerCase();
    const statusFilter = $('#statusFilter')?.value || '';
    const paymentFilter = $('#paymentFilter')?.value || '';
    const filtered = state.learners.filter((learner) => {
      const haystack = [learner.learner_name, learner.id, learner.grade, learner.mode, learner.contact_email, learner.contact_phone, learner.guardian_name].join(' ').toLowerCase();
      return (!query || haystack.includes(query)) && (!statusFilter || learner.enrollment_status === statusFilter) && (!paymentFilter || learner.payment_status === paymentFilter);
    });
    $('#learnersTable').innerHTML = filtered.length ? filtered.map((learner) => `
      <tr class="clickable" data-learner="${escapeHtml(learner.id)}">
        <td class="cell-main">${escapeHtml(learner.learner_name)}<span class="cell-sub">${escapeHtml(learner.id)} · ${learner.is_adult ? '18+' : 'Under 18'}</span></td>
        <td>${escapeHtml(learner.grade)}</td><td>${escapeHtml(learner.mode)}</td><td>${statusPill(learner.enrollment_status)}</td>
        <td>${statusPill(learner.payment_status)}</td><td class="cell-main">${formatRand(learner.balance_cents)}</td><td>${dateShort(learner.created_at)}</td>
      </tr>`).join('') : '<tr><td colspan="7" class="admin-empty">No matching learner records.</td></tr>';
  }

  function renderPaymentViews() {
    $('#paymentsTable').innerHTML = state.payments.length ? state.payments.map((payment) => `
      <tr class="clickable" data-learner="${escapeHtml(payment.learner_id)}">
        <td>${dateTime(payment.created_at)}</td><td class="cell-main">${escapeHtml(payment.learner_name)}<span class="cell-sub">${escapeHtml(payment.learner_id)}</span></td>
        <td>${escapeHtml(payment.grade)}</td><td>${escapeHtml(payment.method)}</td><td>${escapeHtml(payment.reference || '—')}</td><td class="cell-main">${formatRand(payment.amount_cents)}</td>
      </tr>`).join('') : '<tr><td colspan="6" class="admin-empty">No payment transactions recorded yet.</td></tr>';
    $('#outstandingTable').innerHTML = state.outstanding.length ? state.outstanding.map((item) => `
      <tr class="clickable" data-learner="${escapeHtml(item.id)}"><td class="cell-main">${escapeHtml(item.learner_name)}<span class="cell-sub">${escapeHtml(item.id)}</span></td><td>${escapeHtml(item.grade)}</td><td>${statusPill(item.payment_status)}</td><td class="cell-main">${formatRand(item.balance_cents)}</td></tr>`).join('') : '<tr><td colspan="4" class="admin-empty">All recorded learner accounts are settled.</td></tr>';
  }

  function setView(view) {
    if (view === 'website') { window.location.assign('/'); return; }
    state.view = view;
    $$('.admin-view').forEach((node) => { node.hidden = node.id !== `${view}View`; });
    $$('[data-view]').forEach((button) => button.classList.toggle('active', button.dataset.view === view));
    $('#pageTitle').textContent = ({overview: 'Overview', learners: 'Learners', payments: 'Payments'})[view] || 'Overview';
    if (view === 'learners') renderLearners();
  }

  async function openLearner(id) {
    state.currentLearnerId = id;
    drawerOverlay.hidden = false;
    drawerContent.innerHTML = '<div class="admin-panel"><div class="admin-empty">Loading learner record…</div></div>';
    try {
      const learner = await api(`/api/admin/learners/${encodeURIComponent(id)}`);
      state.currentLearnerId = learner.id;
      $('#drawerTitle').textContent = 'Learner record';
      renderLearnerDetail(learner);
    } catch (error) {
      drawerContent.innerHTML = `<div class="detail-card">${escapeHtml(error.message)}</div>`;
    }
  }

  function renderLearnerDetail(learner) {
    const contactType = learner.is_adult ? 'Learner contact' : 'Parent / guardian contact';
    const statusOptions = ['Pending', 'Active', 'Paused', 'Withdrawn'].map((status) => `<option ${learner.enrollment_status === status ? 'selected' : ''}>${status}</option>`).join('');
    const gradeOptions = ['Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12', 'Matric Rewrite'].map((grade) => `<option ${learner.grade === grade ? 'selected' : ''}>${grade}</option>`).join('');
    const modeOptions = ['Online', 'Face-to-face'].map((mode) => `<option ${learner.mode === mode ? 'selected' : ''}>${mode}</option>`).join('');
    const charges = learner.charges?.length ? learner.charges.map((charge) => `
      <div class="charge-line"><span>${escapeHtml(charge.label)}<small class="cell-sub">${dateShort(charge.created_at)}</small></span><strong>${formatRand(charge.balance_cents)} due <small class="cell-sub">${formatRand(charge.amount_cents)} charged</small></strong></div>`).join('') : '<div class="admin-empty">No charges recorded.</div>';
    const payments = learner.payments?.length ? learner.payments.map((payment) => `
      <div class="payment-line"><span>${escapeHtml(payment.method)} · ${dateShort(payment.created_at)}<small class="cell-sub">${escapeHtml(payment.reference || payment.id)}</small></span><strong>${formatRand(payment.amount_cents)}</strong></div>`).join('') : '<div class="admin-empty">No payments recorded.</div>';
    const guardianConsent = learner.is_adult ? 'Not applicable — learner is 18+' : `Guardian consent recorded · ${dateTime(learner.guardian_consent_at)}`;
    const billingUrl = new URL(learner.billing_url, location.origin).href;

    drawerContent.innerHTML = `
      <div class="detail-card">
        <div class="detail-name-row"><div><h3>${escapeHtml(learner.learner_name)}</h3><p>${escapeHtml(learner.id)} · registered ${dateShort(learner.created_at)}</p></div>${statusPill(learner.enrollment_status)}</div>
        <div class="detail-fields">
          <div class="detail-field"><span>Programme</span><strong>${escapeHtml(learner.grade)} · Mathematics</strong></div>
          <div class="detail-field"><span>Learning format</span><strong>${escapeHtml(learner.mode)} · ${formatRand(learner.monthly_fee_cents)}/mo</strong></div>
          <div class="detail-field"><span>Learner age group</span><strong>${learner.is_adult ? '18 or older' : 'Under 18'}</strong></div>
          <div class="detail-field"><span>Marketing opt-in</span><strong>${learner.marketing_opt_in ? 'Yes' : 'No'}</strong></div>
          <div class="detail-field"><span>${contactType}</span><strong>${escapeHtml(learner.contact_name)}</strong></div>
          <div class="detail-field"><span>Email</span><strong>${escapeHtml(learner.contact_email)}</strong></div>
          <div class="detail-field"><span>Phone</span><strong>${escapeHtml(learner.contact_phone)}</strong></div>
          ${!learner.is_adult ? `<div class="detail-field"><span>Guardian consent</span><strong>${escapeHtml(guardianConsent)}</strong></div>` : ''}
        </div>
      </div>
      <div class="detail-card">
        <div class="detail-subhead">Edit learner and contact details</div>
        <form id="learnerDetailsForm">
          <div class="detail-fields">
            <div class="detail-field"><label class="field-label" for="editLearnerName">Learner name</label><input class="text-input" id="editLearnerName" name="learner_name" maxlength="100" value="${escapeHtml(learner.learner_name)}" required></div>
            <div class="detail-field"><label class="field-label" for="editGrade">Grade / programme</label><select class="text-input" id="editGrade" name="grade">${gradeOptions}</select></div>
            <div class="detail-field"><label class="field-label" for="editMode">Learning format</label><select class="text-input" id="editMode" name="mode">${modeOptions}</select></div>
            <div class="detail-field"><label class="field-label" for="editContactName">${escapeHtml(contactType)} name</label><input class="text-input" id="editContactName" name="contact_name" maxlength="100" value="${escapeHtml(learner.contact_name)}" required></div>
            <div class="detail-field"><label class="field-label" for="editContactEmail">Contact email</label><input class="text-input" id="editContactEmail" name="contact_email" type="email" maxlength="254" value="${escapeHtml(learner.contact_email)}" required></div>
            <div class="detail-field"><label class="field-label" for="editContactPhone">Contact phone</label><input class="text-input" id="editContactPhone" name="contact_phone" type="tel" maxlength="24" value="${escapeHtml(learner.contact_phone)}" required></div>
          </div>
          <p class="mini-note">Changing format affects future monthly charges; existing charges and payments are unchanged.</p>
          <button class="button button-dark" type="submit" style="margin-top:10px;min-height:38px;padding:0 13px;font-size:9px">Save learner details</button>
        </form>
      </div>
      <div class="detail-card">
        <div class="detail-subhead">Manage enrolment</div>
        <form id="learnerManageForm">
          <div class="detail-form-row"><div><label class="field-label" for="detailStatus">Status</label><select class="text-input" id="detailStatus">${statusOptions}</select></div><div><label class="field-label" for="detailNotes">Admin note (no sensitive info)</label><input class="text-input" id="detailNotes" maxlength="500" value="${escapeHtml(learner.notes || '')}" placeholder="Optional internal note"></div><button class="button button-dark" type="submit">Save</button></div>
        </form>
      </div>
      <div class="detail-card">
        <div class="detail-subhead">Private fee link <span>${formatRand(learner.balance_cents)} due</span></div>
        <div class="billing-admin-row"><input class="text-input" id="detailBillingLink" readonly value="${escapeHtml(billingUrl)}" aria-label="Private billing link"><button class="button button-light" type="button" data-action="copy-link">Copy</button></div>
        <p class="mini-note">Bearer link: anyone who has it can view the balance and start payment. Share only with the learner or their parent/guardian. Rotate it if it is exposed.</p>
        <button class="button button-light" type="button" data-action="rotate-link" style="margin-top:9px;min-height:33px;padding:0 10px;font-size:8px">Rotate private link</button>
      </div>
      <div class="detail-card">
        <div class="detail-subhead"><span>Charges</span><button class="button button-light" type="button" data-action="add-monthly">Add monthly fee · ${formatRand(learner.monthly_fee_cents)}</button></div>
        ${charges}
        <p class="mini-note">Monthly charges are added manually; this system does not auto-debit recurring fees.</p>
      </div>
      <div class="detail-card">
        <div class="detail-subhead">Record a manual payment</div>
        <form id="manualPaymentForm">
          <div class="detail-fields">
            <div class="detail-field"><label class="field-label" for="paymentAmount">Amount (R)</label><input class="text-input" id="paymentAmount" name="amount" type="number" min="0.01" max="${(Number(learner.balance_cents) / 100).toFixed(2)}" step="0.01" value="${(Number(learner.balance_cents) / 100).toFixed(2)}" required></div>
            <div class="detail-field"><label class="field-label" for="paymentMethod">Method</label><select class="text-input" id="paymentMethod" name="method"><option>EFT</option><option>Cash</option><option>Other</option></select></div>
            <div class="detail-field"><label class="field-label" for="paymentReference">Reference (optional)</label><input class="text-input" id="paymentReference" name="reference" maxlength="100" placeholder="Bank/payment reference"></div>
            <div class="detail-field" style="display:flex;align-items:end"><button class="button button-dark" type="submit" style="width:100%;min-height:39px;padding:0 9px;font-size:9px" ${learner.balance_cents <= 0 ? 'disabled' : ''}>Record payment</button></div>
          </div>
        </form>
      </div>
      <div class="detail-card"><div class="detail-subhead">Payment history</div>${payments}</div>
      <div class="detail-card"><button class="danger-button" type="button" data-action="delete-learner">Delete learner record and linked payment data</button><p class="mini-note">Deletion removes this learner’s record, charges, payment history and billing link from this system.</p></div>`;
  }

  async function handleDrawerAction(event) {
    const actionNode = event.target.closest('[data-action]');
    if (!actionNode || !state.currentLearnerId) return;
    const action = actionNode.dataset.action;
    const id = state.currentLearnerId;
    try {
      if (action === 'copy-link') {
        const value = $('#detailBillingLink').value;
        try { await navigator.clipboard.writeText(value); } catch (_) { $('#detailBillingLink').focus(); $('#detailBillingLink').select(); document.execCommand('copy'); }
        toast('Private fee link copied.');
      } else if (action === 'rotate-link') {
        if (!window.confirm('Rotate this private link? The old link will stop working.')) return;
        const result = await api(`/api/admin/learners/${encodeURIComponent(id)}/billing-link/rotate`, {method: 'POST', body: JSON.stringify({})});
        toast('Private link rotated.');
        await openLearner(id);
      } else if (action === 'add-monthly') {
        const learner = state.learners.find((item) => item.id === id);
        const amount = learner?.monthly_fee_cents || 0;
        if (!window.confirm(`Add a monthly tuition charge of ${formatRand(amount)}? This creates a new amount due; it does not auto-debit.`)) return;
        await api(`/api/admin/learners/${encodeURIComponent(id)}/charges`, {method: 'POST', body: JSON.stringify({confirm: true})});
        toast('Monthly tuition charge added.');
        await refreshAll();
        await openLearner(id);
      } else if (action === 'delete-learner') {
        if (!window.confirm('Delete this learner and all linked charges and payment history? This cannot be undone.')) return;
        await api(`/api/admin/learners/${encodeURIComponent(id)}`, {method: 'DELETE'});
        drawerOverlay.hidden = true;
        toast('Learner record deleted.');
        await refreshAll();
      }
    } catch (error) {
      toast(error.message, true);
    }
  }

  drawerContent.addEventListener('submit', async (event) => {
    event.preventDefault();
    const id = state.currentLearnerId;
    if (event.target.id === 'learnerDetailsForm') {
      const formData = new FormData(event.target);
      try {
        await api(`/api/admin/learners/${encodeURIComponent(id)}`, {
          method: 'PATCH',
          body: JSON.stringify({
            learner_name: formData.get('learner_name'), grade: formData.get('grade'), mode: formData.get('mode'),
            contact_name: formData.get('contact_name'), contact_email: formData.get('contact_email'), contact_phone: formData.get('contact_phone')
          })
        });
        toast('Learner details updated.');
        await refreshAll();
        await openLearner(id);
      } catch (error) { toast(error.message, true); }
    }
    if (event.target.id === 'learnerManageForm') {
      try {
        await api(`/api/admin/learners/${encodeURIComponent(id)}`, {
          method: 'PATCH',
          body: JSON.stringify({enrollment_status: $('#detailStatus').value, notes: $('#detailNotes').value})
        });
        toast('Learner record saved.');
        await refreshAll();
        await openLearner(id);
      } catch (error) { toast(error.message, true); }
    }
    if (event.target.id === 'manualPaymentForm') {
      const formData = new FormData(event.target);
      try {
        await api(`/api/admin/learners/${encodeURIComponent(id)}/payments`, {
          method: 'POST',
          body: JSON.stringify({amount: formData.get('amount'), method: formData.get('method'), reference: formData.get('reference')})
        });
        toast('Payment recorded.');
        await refreshAll();
        await openLearner(id);
      } catch (error) { toast(error.message, true); }
    }
  });

  drawerContent.addEventListener('click', handleDrawerAction);

  $('#loginForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    $('#loginError').textContent = '';
    const submit = $('#loginSubmit');
    submit.disabled = true;
    submit.textContent = 'Signing in…';
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST', headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email: $('#loginEmail').value, password: $('#loginPassword').value}), credentials: 'same-origin'
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Sign-in failed.');
      $('#loginPassword').value = '';
      showDashboard({...data, demo_mode: (await fetch('/api/config').then((r) => r.json())).demo_mode});
    } catch (error) {
      $('#loginError').textContent = error.message || 'Sign-in failed.';
    } finally {
      submit.disabled = false;
      submit.innerHTML = 'Sign in <span aria-hidden="true">↗</span>';
    }
  });

  $('#logoutButton').addEventListener('click', async () => {
    try { await api('/api/admin/logout', {method: 'POST', body: JSON.stringify({})}); } catch (_) {}
    $('#loginForm').reset();
    showLogin();
  });

  $$('[data-view]').forEach((button) => button.addEventListener('click', () => setView(button.dataset.view)));
  $$('[data-open-view]').forEach((button) => button.addEventListener('click', () => setView(button.dataset.openView)));
  $('#learnerSearch').addEventListener('input', renderLearners);
  $('#statusFilter').addEventListener('change', renderLearners);
  $('#paymentFilter').addEventListener('change', renderLearners);
  $('#closeDrawer').addEventListener('click', () => { drawerOverlay.hidden = true; });
  drawerOverlay.addEventListener('click', (event) => { if (event.target === drawerOverlay) drawerOverlay.hidden = true; });
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') drawerOverlay.hidden = true; });
  document.addEventListener('click', (event) => {
    const row = event.target.closest('tr[data-learner]');
    if (row) openLearner(row.dataset.learner);
  });

  $$('[data-payment-tab]').forEach((button) => button.addEventListener('click', () => {
    state.paymentTab = button.dataset.paymentTab;
    $$('[data-payment-tab]').forEach((node) => node.classList.toggle('active', node === button));
    $('#transactionsPanel').hidden = state.paymentTab !== 'transactions';
    $('#outstandingPanel').hidden = state.paymentTab !== 'outstanding';
  }));

  async function init() {
    try {
      const response = await fetch('/api/admin/me', {credentials: 'same-origin', cache: 'no-store'});
      if (!response.ok) throw new Error('Not signed in');
      const session = await response.json();
      showDashboard(session);
    } catch (_) {
      showLogin();
    }
  }

  init();
})();
