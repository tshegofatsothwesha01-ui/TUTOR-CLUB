(() => {
  const params = new URLSearchParams(window.location.search);
  const attempt = params.get('attempt') || '';
  const amount = document.getElementById('checkoutAmount');
  const reference = document.getElementById('checkoutRef');
  const status = document.getElementById('checkoutStatus');
  const simulate = document.getElementById('simulatePayment');
  const cancel = document.getElementById('cancelCheckout');
  const formatRand = (cents) => `R${(Number(cents || 0) / 100).toLocaleString('en-ZA', {minimumFractionDigits: 0, maximumFractionDigits: 2})}`;

  function setStatus(text, error = false) {
    status.textContent = text;
    status.style.color = error ? '#9b4438' : '';
  }

  async function load() {
    if (!/^TC-[A-F0-9]{24}$/.test(attempt)) {
      setStatus('Payment reference is missing or invalid.', true);
      return;
    }
    try {
      const response = await fetch(`/api/payments/quote?attempt=${encodeURIComponent(attempt)}`, {cache: 'no-store'});
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Could not load this checkout.');
      reference.textContent = attempt;
      amount.textContent = formatRand(data.amount_cents);
      if (data.status === 'complete') {
        setStatus('This test payment has already been completed.');
        simulate.disabled = true;
        simulate.textContent = 'Test payment completed';
      } else if (data.status !== 'pending' || !data.demo_mode) {
        throw new Error('This demo checkout is no longer available.');
      } else {
        simulate.disabled = false;
      }
    } catch (error) {
      setStatus(error.message || 'Could not load this checkout.', true);
      simulate.disabled = true;
    }
  }

  simulate.addEventListener('click', async () => {
    simulate.disabled = true;
    simulate.textContent = 'Recording test payment…';
    setStatus('');
    try {
      const response = await fetch('/api/demo/complete', {
        method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({attempt})
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'The test payment was not recorded.');
      window.location.assign(`/payment-return?attempt=${encodeURIComponent(attempt)}&demo=1`);
    } catch (error) {
      setStatus(error.message || 'The test payment was not recorded.', true);
      simulate.disabled = false;
      simulate.textContent = 'Simulate successful test payment';
    }
  });

  cancel.addEventListener('click', () => {
    if (document.referrer && new URL(document.referrer).origin === window.location.origin) history.back();
    else window.location.assign('/');
  });

  load();
})();
