(() => {
  const params = new URLSearchParams(window.location.search);
  const token = params.get('token') || '';
  const $ = (id) => document.getElementById(id);
  const message = $('portalMessage');
  const content = $('portalContent');
  const empty = $('portalEmpty');
  const payButton = $('payNow');
  let quote = null;

  const formatRand = (cents) => `R${(Number(cents || 0) / 100).toLocaleString('en-ZA', {minimumFractionDigits: 0, maximumFractionDigits: 2})}`;

  function status(text, error = false) {
    message.textContent = text;
    message.style.color = error ? '#9b4438' : '';
  }

  function showEmpty(text) {
    content.hidden = true;
    empty.hidden = false;
    empty.textContent = text;
  }

  async function load() {
    if (!token || token.length < 30) {
      status('This payment link is incomplete.', true);
      return showEmpty('Check the link and try again. If you need help, contact Tutor Club using its published contact details.');
    }
    try {
      const response = await fetch(`/api/payments/quote?token=${encodeURIComponent(token)}`, {cache: 'no-store'});
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'We could not open this payment link.');
      quote = result;
      content.hidden = false;
      status('');
      $('portalBalance').textContent = formatRand(result.balance_cents);
      $('portalCharges').innerHTML = (result.charges || []).map((charge) => `<div class="portal-charge"><span>${escapeHtml(charge.label)}</span><strong>${formatRand(charge.balance_cents)}</strong></div>`).join('');
      if (result.credit_cents > 0) {
        $('portalCredit').hidden = false;
        $('portalCredit').querySelector('strong').textContent = `−${formatRand(result.credit_cents)}`;
      }
      $('cancelNotice').hidden = params.get('cancelled') !== '1';
      $('demoNote').hidden = !result.demo_mode;
      if (Number(result.balance_cents) <= 0) {
        payButton.disabled = true;
        payButton.textContent = 'No payment due';
        status('This account has no outstanding balance.');
      } else if (!result.online_payments_enabled) {
        payButton.disabled = true;
        payButton.textContent = 'Online checkout not configured';
        status('Online checkout is not available yet. Please contact Tutor Club to arrange payment.', true);
      }
    } catch (error) {
      status(error.message || 'We could not open this payment link.', true);
      showEmpty('Check the link and try again. If you need help, contact Tutor Club using its published contact details.');
    }
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }

  payButton.addEventListener('click', async () => {
    if (!quote || payButton.disabled) return;
    payButton.disabled = true;
    payButton.textContent = 'Preparing secure checkout…';
    status('');
    try {
      const response = await fetch('/api/payments/checkout', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({token})
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'Checkout could not be started.');
      if (result.mode === 'demo') {
        window.location.assign(result.url);
        return;
      }
      if (result.mode === 'payfast') {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = result.action;
        form.hidden = true;
        for (const field of result.fields) {
          const input = document.createElement('input');
          input.type = 'hidden'; input.name = field.name; input.value = field.value;
          form.appendChild(input);
        }
        document.body.appendChild(form);
        form.submit();
        return;
      }
      throw new Error('Checkout mode is not available.');
    } catch (error) {
      status(error.message || 'Checkout could not be started.', true);
      payButton.disabled = false;
      payButton.innerHTML = 'Continue to payment <span aria-hidden="true">↗</span>';
    }
  });

  load();
})();
