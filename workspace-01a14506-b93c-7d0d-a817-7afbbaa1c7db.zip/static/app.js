(() => {
  const form = document.getElementById('registrationForm');
  if (!form) return;

  const $ = (selector) => document.querySelector(selector);
  const modeRadios = [...document.querySelectorAll('input[name="mode"]')];
  const ageRadios = [...document.querySelectorAll('input[name="age_group"]')];
  const minorPanel = $('#minorContact');
  const adultPanel = $('#adultContact');
  const feePreview = $('#feePreview');
  const message = $('#formMessage');
  const submitButton = $('#submitRegistration');
  let savedBillingUrl = '';
  let isMinor = false;

  const formatRand = (cents) => `R${(Number(cents || 0) / 100).toLocaleString('en-ZA', {minimumFractionDigits: 0, maximumFractionDigits: 2})}`;

  function togglePanel(panel, enabled) {
    panel.hidden = !enabled;
    panel.querySelectorAll('input').forEach((input) => {
      input.disabled = !enabled;
      if (input.type === 'checkbox') input.required = enabled && input.id === 'guardianConsent';
      else input.required = enabled;
    });
  }

  function updateConditionalFields() {
    const age = document.querySelector('input[name="age_group"]:checked')?.value;
    isMinor = age === 'under18';
    togglePanel(minorPanel, isMinor);
    togglePanel(adultPanel, age === 'adult');
    updateFeePreview();
  }

  function updateFeePreview() {
    const mode = document.querySelector('input[name="mode"]:checked')?.value;
    if (!mode) {
      feePreview.innerHTML = '<span>Select a learning format to see the first payment</span><strong>R —</strong>';
      return;
    }
    const monthly = mode === 'Online' ? 25000 : 30000;
    feePreview.innerHTML = `<span>First payment · R100 joining + ${mode === 'Online' ? 'R250' : 'R300'} tuition</span><strong>${formatRand(10000 + monthly)}</strong>`;
  }

  function showMessage(text, success = false) {
    message.textContent = text;
    message.hidden = false;
    message.classList.toggle('success', success);
  }

  ageRadios.forEach((radio) => radio.addEventListener('change', updateConditionalFields));
  modeRadios.forEach((radio) => radio.addEventListener('change', updateFeePreview));
  updateConditionalFields();

  const yearNode = document.getElementById('yearNow');
  if (yearNode) yearNode.textContent = new Date().getFullYear();

  fetch('/api/config').then((response) => response.ok ? response.json() : null).then((config) => {
    if (config?.demo_mode) {
      const ribbon = document.getElementById('previewRibbon');
      if (ribbon) ribbon.hidden = false;
    }
  }).catch(() => {});

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    message.hidden = true;
    if (!form.reportValidity()) return;

    const formData = new FormData(form);
    const payload = {
      learner_name: formData.get('learner_name'),
      grade: formData.get('grade'),
      mode: formData.get('mode'),
      age_group: formData.get('age_group'),
      privacy_consent: formData.has('privacy_consent'),
      marketing_opt_in: formData.has('marketing_opt_in'),
      website: formData.get('website') || ''
    };
    if (payload.age_group === 'under18') {
      payload.guardian_name = formData.get('guardian_name');
      payload.guardian_email = formData.get('guardian_email');
      payload.guardian_phone = formData.get('guardian_phone');
      payload.guardian_consent = formData.has('guardian_consent');
    } else {
      payload.learner_email = formData.get('learner_email');
      payload.learner_phone = formData.get('learner_phone');
    }

    submitButton.disabled = true;
    submitButton.innerHTML = 'Submitting… <span aria-hidden="true">•</span>';
    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || 'We could not submit this registration. Please try again.');

      savedBillingUrl = new URL(result.billing_url, window.location.origin).href;
      $('#successSummary').textContent = `Registration reference ${result.learner_id}. Your first payment includes the one-time joining fee and first month of ${payload.mode.toLowerCase()} tuition.`;
      $('#successAmount').textContent = formatRand(result.amount_due_cents);
      $('#successBreakdown').innerHTML = `<div class="breakdown-line"><span>One-time joining fee</span><strong>${formatRand(result.joining_fee_cents)}</strong></div><div class="breakdown-line"><span>First month · ${payload.mode}</span><strong>${formatRand(result.monthly_fee_cents)}</strong></div>`;
      $('#billingLink').value = savedBillingUrl;
      $('#billingLinkHelp').textContent = isMinor
        ? 'Keep this link private and share it only with the parent or legal guardian. It shows the outstanding balance and opens the payment step.'
        : 'Keep this link private. It shows the outstanding balance and opens the payment step.';
      form.hidden = true;
      $('#registrationSuccess').hidden = false;
      $('#registrationSuccess').scrollIntoView({behavior: 'smooth', block: 'center'});
    } catch (error) {
      showMessage(error.message || 'We could not submit this registration. Please try again.');
      message.scrollIntoView({behavior: 'smooth', block: 'center'});
    } finally {
      submitButton.disabled = false;
      submitButton.innerHTML = 'Submit registration <span aria-hidden="true">↗</span>';
    }
  });

  $('#continuePayment').addEventListener('click', () => {
    if (savedBillingUrl) window.location.assign(savedBillingUrl);
  });

  $('#copyBillingLink').addEventListener('click', async (event) => {
    const button = event.currentTarget;
    try {
      await navigator.clipboard.writeText(savedBillingUrl);
    } catch (_) {
      const input = $('#billingLink');
      input.focus(); input.select();
      document.execCommand('copy');
    }
    button.textContent = 'Copied';
    window.setTimeout(() => { button.textContent = 'Copy link'; }, 1600);
  });

  $('#registerAnother').addEventListener('click', () => {
    form.reset();
    form.hidden = false;
    $('#registrationSuccess').hidden = true;
    message.hidden = true;
    savedBillingUrl = '';
    updateConditionalFields();
    form.scrollIntoView({behavior: 'smooth', block: 'start'});
  });
})();
