(() => {
  const params = new URLSearchParams(location.search);
  const attempt = params.get('attempt') || '';
  const token = params.get('token') || '';
  const title = document.getElementById('returnTitle');
  const message = document.getElementById('returnMessage');
  const icon = document.getElementById('returnIcon');
  const statusNode = document.getElementById('returnStatus');
  const link = document.getElementById('returnAccount');
  const statusLabel = (value) => ({complete: 'Confirmed', pending: 'Awaiting provider confirmation', failed: 'Not completed'}[value] || 'Unknown');

  document.getElementById('returnReference').textContent = /^TC-[A-F0-9]{24}$/.test(attempt) ? attempt : 'Unavailable';
  if (token && token.length >= 30) link.href = `/pay?token=${encodeURIComponent(token)}`;
  link.textContent = token ? 'Return to fee account' : 'Return to Tutor Club';

  if (!/^TC-[A-F0-9]{24}$/.test(attempt)) {
    title.textContent = 'Payment status unavailable.';
    message.textContent = 'The payment reference is missing. Open your private payment link to check the current balance.';
    statusNode.textContent = 'Unavailable';
    return;
  }

  async function checkStatus(count = 0) {
    try {
      const response = await fetch(`/api/payments/status?attempt=${encodeURIComponent(attempt)}`, {cache: 'no-store'});
      const result = await response.json();
      if (!response.ok) throw new Error('Status unavailable');
      statusNode.textContent = statusLabel(result.status);
      if (result.status === 'complete') {
        title.textContent = 'Payment confirmed.';
        message.textContent = 'The account payment has been recorded. You can return to the private fee account to view the updated balance.';
        icon.textContent = '✓';
        icon.style.color = '#456421';
        document.getElementById('returnPreview').hidden = !(new URLSearchParams(location.search).get('demo') === '1');
        return;
      }
      if (result.status === 'failed') {
        title.textContent = 'Payment was not completed.';
        message.textContent = 'The account balance is unchanged. Return to the fee account and try again when ready.';
        icon.textContent = '↺';
        return;
      }
      if (count < 7) {
        window.setTimeout(() => checkStatus(count + 1), 1600);
      } else {
        title.textContent = 'Still awaiting confirmation.';
        message.textContent = 'The provider has not confirmed this transaction yet. Keep the payment reference; your account will update after the confirmation arrives.';
      }
    } catch (_) {
      statusNode.textContent = 'Awaiting confirmation';
      if (count < 3) window.setTimeout(() => checkStatus(count + 1), 1800);
      else {
        title.textContent = 'Status temporarily unavailable.';
        message.textContent = 'Open your private fee account again in a moment to check the current balance.';
      }
    }
  }

  checkStatus();
})();
