# Tutor Club hosting & PayFast setup

This guide deploys the current starter as a **single-instance pilot**. Do not deploy the public preview with demo mode enabled: demo credentials are shown intentionally and demo checkout can simulate payment.

## 1. Prepare the project

1. Create a **private** GitHub repository and upload the project files.
2. Confirm `.env`, `data/tutor_club.sqlite3`, and any exports are not committed. `.gitignore` already excludes them.
3. Choose a domain you control (for example, `tutorclub.example.za`). You can start with the Render service URL, but use the final HTTPS domain for payment testing.

## 2. Create the Render web service

1. In Render, choose **New → Web Service** and connect the private repository.
2. Set the runtime to **Python**.
3. Use these commands:
   - Build: `python -m py_compile app.py`
   - Start: `python app.py --host 0.0.0.0 --port $PORT`
4. Set health-check path to `/health`.
5. Attach a persistent disk mounted at `/var/data` and set `TUTOR_CLUB_DATA_DIR=/var/data`.
6. Keep it to **one instance** while the app uses SQLite. Do not use an ephemeral/free filesystem for learner records. Render documents that free services have ephemeral filesystems and do not support persistent disks; see [Web Services](https://render.com/docs/web-services) and [Free instance limitations](https://render.com/docs/free).

The app resolves the database to `$TUTOR_CLUB_DATA_DIR/tutor_club.sqlite3`. The directory and database are created with restrictive Unix permissions where supported. A persistent disk is not a backup: configure encrypted off-site backups and test a restore.

## 3. Set safe staging environment variables

In the Render service **Environment** settings, add these values. Keep secrets in the host's secret/environment manager—not in Git, front-end code, email, or chat.

```text
DEMO_MODE=0
ADMIN_EMAIL=your-private-admin-email
ADMIN_PASSWORD=a-unique-long-random-password-of-16-plus-characters
PUBLIC_BASE_URL=https://your-final-domain
COOKIE_SECURE=1
TUTOR_CLUB_DATA_DIR=/var/data
PAYFAST_SANDBOX=1
PAYFAST_MERCHANT_ID=
PAYFAST_MERCHANT_KEY=
PAYFAST_PASSPHRASE=
```

With no PayFast credentials, registration and admin work, but online checkout stays disabled. `DEMO_MODE=1` is only for this private workspace preview/local development; **do not set it on an internet-accessible service**.

## 4. Connect a custom domain and HTTPS

1. In Render, add your custom domain to the web service.
2. Copy the DNS records Render provides into your domain registrar's DNS panel. The exact records depend on your domain and Render's instructions.
3. Wait for Render to verify the domain and issue TLS, then open `https://your-final-domain/` and `/health`.
4. Set `PUBLIC_BASE_URL` to the final HTTPS origin with no trailing slash and redeploy.

Render supports custom domains and managed TLS on web services; follow the current [Render domain instructions](https://render.com/docs/web-services#custom-domains).

## 5. Set up PayFast sandbox payments

1. Create/sign in to a PayFast **Sandbox** account at [sandbox.payfast.co.za](https://sandbox.payfast.co.za/). PayFast recommends using the sandbox to test the integration. Sandbox merchant credentials are distinct from live credentials; get the sandbox Merchant ID and Merchant Key from the sandbox account.
2. Create/set the sandbox passphrase in the sandbox account settings, then put the sandbox Merchant ID, Merchant Key and passphrase into the Render environment variables above. Do not commit them.
3. Keep `PAYFAST_SANDBOX=1` and `DEMO_MODE=0`. Confirm `PUBLIC_BASE_URL` is public HTTPS. The app constructs a hosted PayFast checkout and supplies a per-payment `notify_url` at `/api/payfast/itn`. PayFast's hosted integration uses a signed form and sends an ITN to the supplied notify URL; see the [official PayFast developer docs](https://developers.payfast.co.za/).
4. Redeploy. Submit a test learner registration. The initial balance should be **R350 online** or **R400 face-to-face**. Open the private billing link and complete a sandbox payment.
5. Verify the server receives/validates the ITN, the admin Payments view records a PayFast payment, and the private fee link shows the updated balance. Test cancel/failed checkout as well. A return redirect alone is **not** treated as proof of payment.

The callback must be reachable from the public internet. If the provider cannot reach `/api/payfast/itn`, it cannot update the ledger. Review Render logs and PayFast's sandbox transaction/notification details during testing.

## 6. Go live only after successful sandbox testing

1. Get approval to accept payments, complete the business/account checks required by PayFast, and get the **live** Merchant ID, Merchant Key and passphrase.
2. Replace the sandbox credentials in Render with the live credentials; set `PAYFAST_SANDBOX=0`; leave `DEMO_MODE=0`.
3. Verify `PUBLIC_BASE_URL=https://your-final-domain`, `COOKIE_SECURE=1`, and a strong unique admin password.
4. Redeploy and test a controlled live payment and refund/reconciliation before promoting the checkout link.
5. Keep the one-time joining fee and monthly tuition records reconciled. This starter does **not** auto-debit monthly tuition: an administrator adds each later monthly charge, then the learner/guardian uses the private billing link to pay.

## 7. Before real learner data

This is a functional prototype, not a security/legal certification. Before accepting real registrations, have the deployment and POPIA/privacy notice reviewed, publish Tutor Club's privacy contact and retention/deletion schedule, configure encrypted backups and restoration, limit administrator access, and complete a security review. In particular, the current app uses Python's built-in HTTP server and SQLite; for a larger or higher-assurance production service, migrate to a production web framework/server and managed PostgreSQL with access controls and backups.
