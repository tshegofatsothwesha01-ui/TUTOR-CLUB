# Tutor Club learner recruitment system

A responsive Tutor Club website, learner registration flow, private fee link, and admin dashboard. The project runs with the Python standard library and stores records in SQLite.

## Preview

Run locally with:

```bash
python3 app.py
```

Then open `http://localhost:8000`. The workspace live preview runs this same app.

**Preview administrator**

- Email: `admin@tutorclub.demo`
- Password: `TutorClubDemo!2026`

These credentials are deliberately visible only in demo mode so the preview can be tested. Do not use them on a public deployment.

## Included

- Public website advertising Mathematics for Grades 8–12 and Matric Rewrite.
- Fee display: R100 one-time joining fee; R250 monthly online; R300 monthly face-to-face.
- Registration creates the joining-fee and first-month charges; learners choose Online or Face-to-face.
- Under-18 registrations require a parent/legal guardian’s name, email, phone number, and consent. Adult learners provide their own contact details. No date of birth, identity number, school, health details, or card details are requested.
- A private, high-entropy payment link for checking the balance and returning to checkout. Treat it like a password; share it only with the learner or, for a minor, their parent/guardian.
- Admin login, overview, searchable learner records, enrolment status management, privacy-conscious notes, CSV export, payment ledger, payment history, manual EFT/cash recording, monthly charge entry, billing-link rotation, and record deletion.
- A PayFast hosted-checkout adapter, activated only after server-side credentials and a public HTTPS URL are supplied. The account ledger updates from a verified PayFast notification, not merely from a browser redirect.
- A labelled demo checkout in preview mode. It never requests card details and does not move money.

**Billing behaviour:** the initial amount is the joining fee plus the first month. Monthly tuition is not auto-debited. An administrator adds subsequent monthly charges; the learner/guardian can then use the same private fee link to pay online when a gateway is configured.

## Hosting setup: Render example

This is a practical single-instance pilot setup. The app uses SQLite, so its database must live on persistent storage. Render's free web services have an ephemeral filesystem and do not support persistent disks; use a paid web-service instance with a persistent disk if you keep SQLite there. See Render's [web-service guide](https://render.com/docs/web-services) and [free-service limitations](https://render.com/docs/free).

1. **Put the project in a private GitHub repository.** Include `app.py`, `static/`, `requirements.txt`, and this README. Do not commit `.env`, real credentials, or a database containing learner data. The `.gitignore` already excludes `.env` and `data/*.sqlite3`.
2. **Create a Render Web Service** connected to that repository. Select Python. Set the build command to `python -m py_compile app.py` and the start command to `python app.py --host 0.0.0.0 --port $PORT`. Set the health-check path to `/health`.
3. **Attach persistent storage.** Add a disk mounted at `/var/data`, then set `TUTOR_CLUB_DATA_DIR=/var/data`. The code now stores `tutor_club.sqlite3` in that configured directory. Keep this service to one instance while using SQLite; for multiple instances or a larger production service, migrate the database to managed PostgreSQL first.
4. **Set environment variables in Render's Environment page** (not in source code or chat). On any internet-accessible Render service, set `DEMO_MODE=0` from the start, plus a unique `ADMIN_EMAIL`, a strong `ADMIN_PASSWORD` (at least 16 characters), `COOKIE_SECURE=1`, `TUTOR_CLUB_DATA_DIR=/var/data`, and the public HTTPS `PUBLIC_BASE_URL`. Without gateway credentials, registration works but online checkout stays disabled. For sandbox testing, add PayFast sandbox credentials and keep `PAYFAST_SANDBOX=1`. **Never expose a public deployment with `DEMO_MODE=1`**: demo credentials are intentionally returned to the preview UI and test payments can be simulated.
5. **Add your custom domain** in the Render service settings. Follow the DNS records Render gives you and wait for TLS/HTTPS to become active. Then set `PUBLIC_BASE_URL=https://your-real-domain` exactly (no trailing slash) and redeploy. Render documents custom domains and managed TLS in its [web-service guide](https://render.com/docs/web-services).
6. **Test the full flow on the sandbox URL.** Register a test learner; confirm the initial amount is R350 online or R400 face-to-face; complete a sandbox payment; wait for PayFast's ITN; verify that the private fee link shows the updated balance and the admin Payments view shows the payment. Also test cancellation, incorrect signature/amount rejection, login, CSV export, and deletion of the test learner.
7. **Only after those checks**, switch to live PayFast credentials and set `PAYFAST_SANDBOX=0`. Keep `DEMO_MODE=0`. Run one controlled live payment/refund and verify ledger reconciliation before advertising checkout.

Configure encrypted backups and test restoration before collecting real learner data. A Render disk is persistent storage, not a substitute for backups. Do not run multiple app instances against this SQLite database.

## Payment configuration (PayFast)

PayFast is the optional default gateway adapter in this South African starter. No merchant credentials are included. In demo mode, the “simulate successful test payment” button only records a demo ledger entry.

For a real deployment, create a PayFast merchant account and test in its sandbox first. Set the environment variables on the server (never in browser code):

```bash
DEMO_MODE=0
ADMIN_EMAIL=admin@your-domain.example
ADMIN_PASSWORD='use-a-unique-password-at-least-16-characters-long'
PUBLIC_BASE_URL=https://your-public-domain.example
COOKIE_SECURE=1
PAYFAST_MERCHANT_ID=your-merchant-id
PAYFAST_MERCHANT_KEY=your-merchant-key
PAYFAST_PASSPHRASE=your-passphrase
PAYFAST_SANDBOX=1
```

Start the application with those variables present. Set `PAYFAST_SANDBOX=0` only after a successful end-to-end test and approval to accept real payments. The public HTTPS `PUBLIC_BASE_URL` must be reachable by PayFast so its ITN callback can reach `/api/payfast/itn`. The app checks the ITN signature, merchant, expected amount, and PayFast’s server-to-server validation response before recording a payment. Confirm the current PayFast integration requirements with PayFast and perform a live checklist before going into production.

The application does not store card numbers or initiate automatic recurring debits. The payment processor will receive the payer’s contact details needed to process a hosted checkout.

## Privacy and security notes

- Public pages do not expose learner records. Admin endpoints require an authenticated session; admin changes are protected with a CSRF token, and the session cookie is HttpOnly and SameSite Strict.
- Admin passwords are compared using PBKDF2-HMAC-SHA256; failed sign-ins are rate-limited in process memory. Registration also has a basic per-IP rate limit and a honeypot field.
- Consent version and timestamps are stored for registration and guardian consent. Marketing is optional and off by default.
- Learner/payment records are stored in `data/tutor_club.sqlite3`; that directory is excluded from Git. SQLite data is not application-level encrypted in this starter. Protect the host, database, exports and backups; use encrypted storage/backups and least-privilege access in production.
- Private fee links are bearer tokens. Rotate a link in the admin drawer if it is exposed. Do not put a private billing URL in a public post or shared spreadsheet.
- The preview uses an in-memory rate limiter and a single-process SQLite setup. For a public service, add operational monitoring, robust rate limiting, backups/restore tests, deployment hardening and a reviewed data retention process.
- Before collecting real learner data, add Tutor Club’s privacy contact details and a clear retention/deletion schedule, finalise the privacy notice and guardian consent wording, review the POPIA obligations with an appropriate professional, and ensure HTTPS, hosting, data backups and administrator access are ready. The notice in the prototype is a product draft, not legal advice.

## Project layout

```text
app.py                   Python web server and API
static/index.html         Public website and registration
static/admin.html         Admin dashboard
static/payment-portal.html Private account/payment portal
static/checkout.html      Clearly labelled demo checkout
static/payment-return.html Payment confirmation status
static/*.js, *.css        Browser behaviour and styles
data/tutor_club.sqlite3   Created automatically at runtime (private data)
```
