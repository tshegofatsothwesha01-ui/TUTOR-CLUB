#!/usr/bin/env python3
"""Tutor Club learner recruitment and fee-tracking starter app.

Uses only Python's standard library. Demo mode is intentionally enabled by default;
real PayFast checkout is activated only when server-side credentials and a public
HTTPS base URL are configured.
"""
from __future__ import annotations

import csv
import hashlib
import hmac
import io
import json
import mimetypes
import os
import re
import secrets
import sqlite3
import threading
import time
import urllib.parse
import urllib.request
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from http.cookies import SimpleCookie
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
DATA_DIR = Path(os.getenv("TUTOR_CLUB_DATA_DIR", str(ROOT / "data"))).expanduser().resolve()
DB_PATH = DATA_DIR / "tutor_club.sqlite3"

DEMO_MODE = os.getenv("DEMO_MODE", "1").strip().lower() not in {"0", "false", "no"}
ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@tutorclub.demo").strip().lower()
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD") or ("TutorClubDemo!2026" if DEMO_MODE else "")
ADMIN_PASSWORD = ADMIN_PASSWORD or ""
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").strip().rstrip("/")
PAYFAST_MERCHANT_ID = os.getenv("PAYFAST_MERCHANT_ID", "").strip()
PAYFAST_MERCHANT_KEY = os.getenv("PAYFAST_MERCHANT_KEY", "").strip()
PAYFAST_PASSPHRASE = os.getenv("PAYFAST_PASSPHRASE", "")
PAYFAST_SANDBOX = os.getenv("PAYFAST_SANDBOX", "1").strip().lower() not in {"0", "false", "no"}
PAYFAST_BASE = "https://sandbox.payfast.co.za" if PAYFAST_SANDBOX else "https://www.payfast.co.za"
PAYFAST_ENABLED = bool(
    PAYFAST_MERCHANT_ID
    and PAYFAST_MERCHANT_KEY
    and PUBLIC_BASE_URL.startswith("https://")
)
COOKIE_SECURE = os.getenv("COOKIE_SECURE", "auto").strip().lower()

JOINING_FEE_CENTS = 10000
ONLINE_MONTHLY_CENTS = 25000
FACE_TO_FACE_MONTHLY_CENTS = 30000
GRADES = {"Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12", "Matric Rewrite"}
MODES = {"Online", "Face-to-face"}
STATUSES = {"Pending", "Active", "Paused", "Withdrawn"}
CONSENT_VERSION = "tutor-club-privacy-v1-2026-10"
SESSION_MAX_AGE = 12 * 60 * 60
PBKDF2_ROUNDS = 240_000

_login_attempts: dict[str, list[float]] = {}
_registration_attempts: dict[str, list[float]] = {}
_attempt_lock = threading.Lock()


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def new_id(prefix: str = "TC") -> str:
    return f"{prefix}-{secrets.token_hex(12).upper()}"


def new_billing_token() -> str:
    return secrets.token_urlsafe(32)


@contextmanager
def db_conn():
    DATA_DIR.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(DATA_DIR, 0o700)
    except OSError:
        pass
    conn = sqlite3.connect(DB_PATH, timeout=10)
    try:
        os.chmod(DB_PATH, 0o600)
    except OSError:
        pass
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    with db_conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS learners (
                id TEXT PRIMARY KEY,
                billing_token TEXT NOT NULL UNIQUE,
                learner_name TEXT NOT NULL,
                grade TEXT NOT NULL,
                mode TEXT NOT NULL,
                is_adult INTEGER NOT NULL,
                guardian_name TEXT,
                contact_name TEXT NOT NULL,
                contact_email TEXT NOT NULL,
                contact_phone TEXT NOT NULL,
                created_at TEXT NOT NULL,
                privacy_consent_at TEXT NOT NULL,
                consent_version TEXT NOT NULL,
                guardian_consent_at TEXT,
                marketing_opt_in INTEGER NOT NULL DEFAULT 0,
                enrollment_status TEXT NOT NULL DEFAULT 'Pending',
                notes TEXT NOT NULL DEFAULT ''
            );
            CREATE INDEX IF NOT EXISTS idx_learners_created ON learners(created_at DESC);
            CREATE INDEX IF NOT EXISTS idx_learners_status ON learners(enrollment_status);

            CREATE TABLE IF NOT EXISTS charges (
                id TEXT PRIMARY KEY,
                learner_id TEXT NOT NULL REFERENCES learners(id) ON DELETE CASCADE,
                label TEXT NOT NULL,
                amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
                created_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_charges_learner ON charges(learner_id, created_at);

            CREATE TABLE IF NOT EXISTS payment_attempts (
                id TEXT PRIMARY KEY,
                learner_id TEXT NOT NULL REFERENCES learners(id) ON DELETE CASCADE,
                amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
                provider TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TEXT NOT NULL,
                gateway_payment_id TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_attempts_learner ON payment_attempts(learner_id, created_at DESC);

            CREATE TABLE IF NOT EXISTS payments (
                id TEXT PRIMARY KEY,
                learner_id TEXT NOT NULL REFERENCES learners(id) ON DELETE CASCADE,
                amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
                method TEXT NOT NULL,
                reference TEXT NOT NULL DEFAULT '',
                status TEXT NOT NULL DEFAULT 'COMPLETE',
                created_at TEXT NOT NULL,
                attempt_id TEXT UNIQUE,
                gateway_ref TEXT UNIQUE
            );
            CREATE INDEX IF NOT EXISTS idx_payments_learner ON payments(learner_id, created_at DESC);

            CREATE TABLE IF NOT EXISTS admin_sessions (
                token_hash TEXT PRIMARY KEY,
                csrf_token TEXT NOT NULL,
                expires_at REAL NOT NULL,
                created_at TEXT NOT NULL
            );
            """
        )


def email_ok(value: str) -> bool:
    if len(value) > 254 or len(value) < 3:
        return False
    return bool(re.fullmatch(r"[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+", value))


def phone_ok(value: str) -> bool:
    return 7 <= len(value) <= 24 and bool(re.fullmatch(r"[0-9+()\-\s]{7,24}", value))


def cents_from_amount(value: Any) -> int:
    try:
        amount = Decimal(str(value)).quantize(Decimal("0.01"))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Enter a valid amount.")
    cents = int(amount * 100)
    if cents <= 0:
        raise ValueError("Amount must be greater than zero.")
    return cents


def clean_text(value: Any, limit: int) -> str:
    if not isinstance(value, str):
        return ""
    return " ".join(value.strip().split())[:limit]


def trim_rate(bucket: dict[str, list[float]], key: str, seconds: int) -> list[float]:
    now = time.time()
    with _attempt_lock:
        recent = [t for t in bucket.get(key, []) if now - t < seconds]
        bucket[key] = recent
        return recent


def rate_limited(bucket: dict[str, list[float]], key: str, seconds: int, maximum: int) -> bool:
    recent = trim_rate(bucket, key, seconds)
    return len(recent) >= maximum


def record_attempt(bucket: dict[str, list[float]], key: str, seconds: int) -> None:
    now = time.time()
    with _attempt_lock:
        bucket[key] = [t for t in bucket.get(key, []) if now - t < seconds] + [now]


def balance_for(conn: sqlite3.Connection, learner_id: str) -> dict[str, int]:
    row = conn.execute(
        """SELECT
            COALESCE((SELECT SUM(amount_cents) FROM charges WHERE learner_id = ?), 0) AS charged,
            COALESCE((SELECT SUM(amount_cents) FROM payments WHERE learner_id = ? AND status = 'COMPLETE'), 0) AS paid
        """,
        (learner_id, learner_id),
    ).fetchone()
    charged, paid = int(row["charged"] or 0), int(row["paid"] or 0)
    return {"charged_cents": charged, "paid_cents": paid,
            "balance_cents": max(0, charged - paid), "credit_cents": max(0, paid - charged)}


def learner_summary(conn: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    result = dict(row)
    result.pop("billing_token", None)
    totals = balance_for(conn, result["id"])
    result.update(totals)
    result["monthly_fee_cents"] = ONLINE_MONTHLY_CENTS if result["mode"] == "Online" else FACE_TO_FACE_MONTHLY_CENTS
    result["joining_fee_cents"] = JOINING_FEE_CENTS
    if totals["charged_cents"] == 0:
        result["payment_status"] = "No charges"
    elif totals["balance_cents"] == 0:
        result["payment_status"] = "Paid"
    elif totals["paid_cents"] > 0:
        result["payment_status"] = "Part-paid"
    else:
        result["payment_status"] = "Due"
    return result


def allocated_charges(conn: sqlite3.Connection, learner_id: str) -> list[dict[str, Any]]:
    rows = conn.execute(
        "SELECT * FROM charges WHERE learner_id = ? ORDER BY created_at ASC, CASE WHEN label = 'One-time joining fee' THEN 0 ELSE 1 END ASC, id ASC", (learner_id,)
    ).fetchall()
    total_paid = conn.execute(
        "SELECT COALESCE(SUM(amount_cents), 0) AS paid FROM payments WHERE learner_id = ? AND status = 'COMPLETE'",
        (learner_id,),
    ).fetchone()["paid"]
    remaining_paid = int(total_paid or 0)
    result: list[dict[str, Any]] = []
    for row in rows:
        item = dict(row)
        allocated = min(remaining_paid, int(item["amount_cents"]))
        remaining_paid -= allocated
        item["paid_cents"] = allocated
        item["balance_cents"] = int(item["amount_cents"]) - allocated
        result.append(item)
    return result


def php_urlencode(value: Any) -> str:
    # PayFast's custom-checkout signature uses PHP urlencode semantics (spaces as +).
    return urllib.parse.quote_plus(str(value).strip(), safe="").replace("~", "%7E")


def payfast_signature(items: list[tuple[str, str]], passphrase: str) -> str:
    parts = []
    for key, value in items:
        if key == "signature":
            continue
        val = str(value).strip()
        if val != "":
            parts.append(f"{key}={php_urlencode(val)}")
    query = "&".join(parts)
    if passphrase:
        query += "&passphrase=" + php_urlencode(passphrase)
    return hashlib.md5(query.encode("utf-8")).hexdigest()


def admin_password_digest(password: str) -> bytes:
    # The password itself is never persisted in the database or returned to a client.
    salt = hashlib.sha256(("tutor-club-admin:" + ADMIN_EMAIL).encode("utf-8")).digest()
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)


class TutorClubHandler(__import__("http.server").server.BaseHTTPRequestHandler):
    server_version = "TutorClub/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        # Avoid writing learner/admin request details to console logs.
        return

    def security_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        if not DEMO_MODE:
            self.send_header("X-Frame-Options", "SAMEORIGIN")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        frame_policy = "*" if DEMO_MODE else "'self'"
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:; connect-src 'self'; form-action 'self' https://sandbox.payfast.co.za https://www.payfast.co.za; "
            f"base-uri 'self'; frame-ancestors {frame_policy}; object-src 'none'",
        )

    def send_json(self, status: int, value: Any) -> None:
        body = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.security_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, status: int, text: str, content_type: str = "text/plain; charset=utf-8") -> None:
        body = text.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store, max-age=0")
        self.security_headers()
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, file_path: Path, cache: str = "no-cache") -> None:
        try:
            body = file_path.read_bytes()
        except FileNotFoundError:
            self.send_json(404, {"error": "Not found."})
            return
        content_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in {"application/javascript", "image/svg+xml"}:
            content_type += "; charset=utf-8"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", cache)
        self.security_headers()
        self.end_headers()
        self.wfile.write(body)

    def parse_body(self, max_bytes: int = 64_000) -> bytes:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise ValueError("Invalid request size.")
        if length < 0 or length > max_bytes:
            raise ValueError("Request is too large.")
        return self.rfile.read(length)

    def read_json(self) -> dict[str, Any]:
        raw = self.parse_body()
        if not raw:
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Invalid request data.")
        if not isinstance(data, dict):
            raise ValueError("Invalid request data.")
        return data

    def request_ip(self) -> str:
        return self.client_address[0] if self.client_address else "unknown"

    def session_cookie_secure(self) -> bool:
        if COOKIE_SECURE in {"1", "true", "yes", "on"}:
            return True
        if COOKIE_SECURE in {"0", "false", "no", "off"}:
            return False
        forwarded = self.headers.get("X-Forwarded-Proto", "").split(",")[0].strip().lower()
        return forwarded == "https"

    def get_session(self) -> sqlite3.Row | None:
        cookie_header = self.headers.get("Cookie", "")
        cookie = SimpleCookie()
        try:
            cookie.load(cookie_header)
        except Exception:
            return None
        morsel = cookie.get("tc_admin")
        if not morsel:
            return None
        token_hash = hashlib.sha256(morsel.value.encode()).hexdigest()
        with db_conn() as conn:
            row = conn.execute(
                "SELECT * FROM admin_sessions WHERE token_hash = ? AND expires_at > ?",
                (token_hash, time.time()),
            ).fetchone()
            return row

    def require_admin(self, csrf: bool = False) -> sqlite3.Row | None:
        session = self.get_session()
        if not session:
            self.send_json(401, {"error": "Please sign in again."})
            return None
        if csrf:
            supplied = self.headers.get("X-CSRF-Token", "")
            if not supplied or not hmac.compare_digest(supplied, session["csrf_token"]):
                self.send_json(403, {"error": "Security token expired. Refresh and try again."})
                return None
        return session

    def make_cookie(self, token: str, max_age: int) -> str:
        value = f"tc_admin={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={max_age}"
        if self.session_cookie_secure():
            value += "; Secure"
        return value

    def do_HEAD(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        files = {
            "/": STATIC_DIR / "index.html",
            "/admin": STATIC_DIR / "admin.html",
            "/admin/": STATIC_DIR / "admin.html",
            "/pay": STATIC_DIR / "payment-portal.html",
            "/pay/": STATIC_DIR / "payment-portal.html",
            "/checkout": STATIC_DIR / "checkout.html",
            "/payment-return": STATIC_DIR / "payment-return.html",
        }
        if path.startswith("/static/"):
            relative = path.removeprefix("/static/")
            if "/" not in relative and not relative.startswith("."):
                files[path] = STATIC_DIR / relative
        file_path = files.get(path)
        if file_path and file_path.is_file():
            body = file_path.read_bytes()
            content_type = mimetypes.guess_type(str(file_path))[0] or "application/octet-stream"
            if content_type.startswith("text/") or content_type in {"application/javascript", "image/svg+xml"}:
                content_type += "; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-cache")
            self.security_headers()
            self.end_headers()
            return
        if path == "/health":
            body = b'{"status":"ok"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.security_headers()
            self.end_headers()
            return
        self.send_response(404)
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        if path == "/":
            return self.send_file(STATIC_DIR / "index.html")
        if path in {"/admin", "/admin/"}:
            return self.send_file(STATIC_DIR / "admin.html")
        if path in {"/pay", "/pay/"}:
            return self.send_file(STATIC_DIR / "payment-portal.html")
        if path == "/checkout":
            return self.send_file(STATIC_DIR / "checkout.html")
        if path == "/payment-return":
            return self.send_file(STATIC_DIR / "payment-return.html")
        if path == "/robots.txt":
            return self.send_text(200, "User-agent: *\nDisallow: /admin\nDisallow: /api/\n")
        if path == "/health":
            return self.send_json(200, {"status": "ok"})
        if path == "/favicon.ico":
            self.send_response(204)
            self.end_headers()
            return
        if path.startswith("/static/"):
            relative = path.removeprefix("/static/")
            if "/" in relative or relative.startswith("."):
                return self.send_json(404, {"error": "Not found."})
            return self.send_file(STATIC_DIR / relative)

        if path == "/api/config":
            return self.send_json(200, {
                "demo_mode": DEMO_MODE,
                "online_payments_enabled": PAYFAST_ENABLED or DEMO_MODE,
                "payment_provider": "PayFast" if PAYFAST_ENABLED else ("Demo checkout" if DEMO_MODE else None),
                "joining_fee_cents": JOINING_FEE_CENTS,
                "online_monthly_cents": ONLINE_MONTHLY_CENTS,
                "face_to_face_monthly_cents": FACE_TO_FACE_MONTHLY_CENTS,
                **({"demo_admin_email": ADMIN_EMAIL, "demo_admin_password": ADMIN_PASSWORD} if DEMO_MODE else {}),
            })
        if path == "/api/payments/quote":
            query = urllib.parse.parse_qs(parsed.query)
            token = (query.get("token") or [""])[0]
            if token:
                return self.payment_quote(token)
            attempt = (query.get("attempt") or [""])[0]
            if attempt:
                return self.attempt_quote(attempt)
            return self.send_json(400, {"error": "Payment link is missing."})
        if path == "/api/payments/status":
            query = urllib.parse.parse_qs(parsed.query)
            attempt_id = (query.get("attempt") or [""])[0]
            if not re.fullmatch(r"TC-[A-F0-9]{24}", attempt_id):
                return self.send_json(404, {"error": "Payment attempt not found."})
            with db_conn() as conn:
                row = conn.execute("SELECT status FROM payment_attempts WHERE id = ?", (attempt_id,)).fetchone()
            if not row:
                return self.send_json(404, {"error": "Payment attempt not found."})
            return self.send_json(200, {"status": row["status"]})

        if path == "/api/admin/me":
            session = self.get_session()
            if not session:
                return self.send_json(401, {"error": "Not signed in."})
            return self.send_json(200, {"email": ADMIN_EMAIL, "csrf_token": session["csrf_token"], "demo_mode": DEMO_MODE})
        if path == "/api/admin/summary":
            if not self.require_admin():
                return
            return self.admin_summary()
        if path == "/api/admin/learners":
            if not self.require_admin():
                return
            query = urllib.parse.parse_qs(parsed.query)
            search = clean_text((query.get("q") or [""])[0], 100).casefold()
            return self.admin_learners(search)
        if path == "/api/admin/payments":
            if not self.require_admin():
                return
            return self.admin_payments()
        if path == "/api/admin/export.csv":
            if not self.require_admin():
                return
            return self.export_csv()
        match = re.fullmatch(r"/api/admin/learners/([A-Z0-9-]+)", path)
        if match:
            if not self.require_admin():
                return
            return self.admin_learner_detail(match.group(1))
        return self.send_json(404, {"error": "Not found."})

    def do_POST(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        try:
            if path == "/api/register":
                return self.register_learner()
            if path == "/api/admin/login":
                return self.admin_login()
            if path == "/api/admin/logout":
                if not self.require_admin(csrf=True):
                    return
                session = self.get_session()
                with db_conn() as conn:
                    conn.execute("DELETE FROM admin_sessions WHERE token_hash = ?", (session["token_hash"],))
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", "2")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Set-Cookie", self.make_cookie("", 0))
                self.security_headers()
                self.end_headers()
                self.wfile.write(b"{}")
                return
            if path == "/api/payments/checkout":
                return self.start_checkout()
            if path == "/api/demo/complete":
                return self.complete_demo_payment()
            if path == "/api/payfast/itn":
                return self.process_payfast_itn()
            match = re.fullmatch(r"/api/admin/learners/([A-Z0-9-]+)/payments", path)
            if match:
                if not self.require_admin(csrf=True):
                    return
                return self.record_manual_payment(match.group(1))
            match = re.fullmatch(r"/api/admin/learners/([A-Z0-9-]+)/charges", path)
            if match:
                if not self.require_admin(csrf=True):
                    return
                return self.add_monthly_charge(match.group(1))
            match = re.fullmatch(r"/api/admin/learners/([A-Z0-9-]+)/billing-link/rotate", path)
            if match:
                if not self.require_admin(csrf=True):
                    return
                return self.rotate_billing_link(match.group(1))
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        except Exception:
            return self.send_json(500, {"error": "Something went wrong. Please try again."})
        return self.send_json(404, {"error": "Not found."})

    def do_PATCH(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        match = re.fullmatch(r"/api/admin/learners/([A-Z0-9-]+)", path)
        if not match:
            return self.send_json(404, {"error": "Not found."})
        if not self.require_admin(csrf=True):
            return
        try:
            data = self.read_json()
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        learner_id = match.group(1)
        with db_conn() as conn:
            current = conn.execute("SELECT * FROM learners WHERE id = ?", (learner_id,)).fetchone()
            if not current:
                return self.send_json(404, {"error": "Learner record not found."})
            status = data.get("enrollment_status", current["enrollment_status"])
            notes = data.get("notes", current["notes"])
            if status not in STATUSES:
                return self.send_json(400, {"error": "Choose a valid enrolment status."})
            if not isinstance(notes, str) or len(notes) > 500:
                return self.send_json(400, {"error": "Notes must be 500 characters or fewer."})
            fields_changed = any(k in data for k in ("learner_name", "grade", "mode", "contact_name", "contact_email", "contact_phone"))
            learner_name = clean_text(data.get("learner_name", current["learner_name"]), 100)
            grade = clean_text(data.get("grade", current["grade"]), 40)
            mode = clean_text(data.get("mode", current["mode"]), 40)
            contact_name = clean_text(data.get("contact_name", current["contact_name"]), 100)
            contact_email = clean_text(data.get("contact_email", current["contact_email"]), 254).lower()
            contact_phone = clean_text(data.get("contact_phone", current["contact_phone"]), 24)
            if fields_changed:
                if len(learner_name) < 2:
                    return self.send_json(400, {"error": "Enter the learner's name."})
                if grade not in GRADES or mode not in MODES:
                    return self.send_json(400, {"error": "Choose a valid grade and learning format."})
                if len(contact_name) < 2 or not email_ok(contact_email) or not phone_ok(contact_phone):
                    return self.send_json(400, {"error": "Enter a contact name, valid email and valid phone number."})
                guardian_name = "" if current["is_adult"] else contact_name
                conn.execute(
                    """UPDATE learners SET learner_name = ?, grade = ?, mode = ?, guardian_name = ?,
                       contact_name = ?, contact_email = ?, contact_phone = ? WHERE id = ?""",
                    (learner_name, grade, mode, guardian_name, contact_name, contact_email, contact_phone, learner_id),
                )
            conn.execute(
                "UPDATE learners SET enrollment_status = ?, notes = ? WHERE id = ?",
                (status, notes.strip(), learner_id),
            )
        return self.send_json(200, {"ok": True})

    def do_DELETE(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        match = re.fullmatch(r"/api/admin/learners/([A-Z0-9-]+)", path)
        if not match:
            return self.send_json(404, {"error": "Not found."})
        if not self.require_admin(csrf=True):
            return
        with db_conn() as conn:
            cur = conn.execute("DELETE FROM learners WHERE id = ?", (match.group(1),))
            if cur.rowcount == 0:
                return self.send_json(404, {"error": "Learner record not found."})
        return self.send_json(200, {"ok": True})

    def register_learner(self) -> None:
        if rate_limited(_registration_attempts, self.request_ip(), 3600, 10):
            return self.send_json(429, {"error": "Too many attempts. Please try again later."})
        try:
            data = self.read_json()
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        if clean_text(data.get("website"), 200):
            return self.send_json(400, {"error": "Unable to process this registration."})
        learner_name = clean_text(data.get("learner_name"), 100)
        grade = clean_text(data.get("grade"), 40)
        mode = clean_text(data.get("mode"), 40)
        age_group = data.get("age_group")
        if len(learner_name) < 2:
            return self.send_json(400, {"error": "Enter the learner's name."})
        if grade not in GRADES:
            return self.send_json(400, {"error": "Choose a valid grade or Matric Rewrite."})
        if mode not in MODES:
            return self.send_json(400, {"error": "Choose online or face-to-face tuition."})
        if age_group not in {"under18", "adult"}:
            return self.send_json(400, {"error": "Select whether the learner is under 18."})
        if data.get("privacy_consent") is not True:
            return self.send_json(400, {"error": "Please confirm the privacy notice to continue."})

        is_adult = age_group == "adult"
        learner_email = clean_text(data.get("learner_email"), 254).lower()
        learner_phone = clean_text(data.get("learner_phone"), 24)
        guardian_name = clean_text(data.get("guardian_name"), 100)
        guardian_email = clean_text(data.get("guardian_email"), 254).lower()
        guardian_phone = clean_text(data.get("guardian_phone"), 24)
        if is_adult:
            if not email_ok(learner_email):
                return self.send_json(400, {"error": "Enter a valid learner email address."})
            if not phone_ok(learner_phone):
                return self.send_json(400, {"error": "Enter a valid learner phone number."})
            contact_name, contact_email, contact_phone = learner_name, learner_email, learner_phone
            guardian_name = ""
            guardian_consent_at = None
        else:
            if len(guardian_name) < 2:
                return self.send_json(400, {"error": "Enter the parent or guardian's name."})
            if not email_ok(guardian_email):
                return self.send_json(400, {"error": "Enter a valid parent or guardian email address."})
            if not phone_ok(guardian_phone):
                return self.send_json(400, {"error": "Enter a valid parent or guardian phone number."})
            if data.get("guardian_consent") is not True:
                return self.send_json(400, {"error": "A parent or legal guardian must confirm consent for a learner under 18."})
            contact_name, contact_email, contact_phone = guardian_name, guardian_email, guardian_phone
            guardian_consent_at = utc_now()
        record_attempt(_registration_attempts, self.request_ip(), 3600)

        learner_id = new_id()
        billing_token = new_billing_token()
        created = utc_now()
        monthly_fee = ONLINE_MONTHLY_CENTS if mode == "Online" else FACE_TO_FACE_MONTHLY_CENTS
        with db_conn() as conn:
            conn.execute(
                """INSERT INTO learners (
                    id, billing_token, learner_name, grade, mode, is_adult, guardian_name,
                    contact_name, contact_email, contact_phone, created_at, privacy_consent_at,
                    consent_version, guardian_consent_at, marketing_opt_in, enrollment_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')""",
                (learner_id, billing_token, learner_name, grade, mode, int(is_adult), guardian_name,
                 contact_name, contact_email, contact_phone, created, created, CONSENT_VERSION,
                 guardian_consent_at, int(bool(data.get("marketing_opt_in")))),
            )
            conn.execute(
                "INSERT INTO charges (id, learner_id, label, amount_cents, created_at) VALUES (?, ?, ?, ?, ?)",
                (new_id("CHG"), learner_id, "One-time joining fee", JOINING_FEE_CENTS, created),
            )
            conn.execute(
                "INSERT INTO charges (id, learner_id, label, amount_cents, created_at) VALUES (?, ?, ?, ?, ?)",
                (new_id("CHG"), learner_id, "First month — " + mode, monthly_fee, created),
            )
        return self.send_json(201, {
            "ok": True,
            "learner_id": learner_id,
            "billing_url": f"/pay?token={urllib.parse.quote(billing_token)}",
            "joining_fee_cents": JOINING_FEE_CENTS,
            "monthly_fee_cents": monthly_fee,
            "amount_due_cents": JOINING_FEE_CENTS + monthly_fee,
            "demo_mode": DEMO_MODE,
            "online_payments_enabled": PAYFAST_ENABLED or DEMO_MODE,
        })

    def admin_login(self) -> None:
        ip = self.request_ip()
        if rate_limited(_login_attempts, ip, 900, 8):
            return self.send_json(429, {"error": "Too many sign-in attempts. Wait 15 minutes and try again."})
        try:
            data = self.read_json()
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        email = clean_text(data.get("email"), 254).lower()
        password = data.get("password") if isinstance(data.get("password"), str) else ""
        valid = (
            bool(ADMIN_PASSWORD)
            and hmac.compare_digest(email, ADMIN_EMAIL)
            and hmac.compare_digest(admin_password_digest(password), admin_password_digest(ADMIN_PASSWORD))
        )
        if not valid:
            record_attempt(_login_attempts, ip, 900)
            return self.send_json(401, {"error": "Email or password is incorrect."})
        with _attempt_lock:
            _login_attempts.pop(ip, None)
        raw_token = secrets.token_urlsafe(32)
        csrf_token = secrets.token_urlsafe(32)
        token_hash = hashlib.sha256(raw_token.encode()).hexdigest()
        expires_at = time.time() + SESSION_MAX_AGE
        with db_conn() as conn:
            conn.execute("DELETE FROM admin_sessions WHERE expires_at <= ?", (time.time(),))
            conn.execute(
                "INSERT INTO admin_sessions (token_hash, csrf_token, expires_at, created_at) VALUES (?, ?, ?, ?)",
                (token_hash, csrf_token, expires_at, utc_now()),
            )
        body = json.dumps({"ok": True, "email": ADMIN_EMAIL, "csrf_token": csrf_token}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Set-Cookie", self.make_cookie(raw_token, SESSION_MAX_AGE))
        self.security_headers()
        self.end_headers()
        self.wfile.write(body)

    def payment_quote(self, token: str) -> None:
        if len(token) < 30 or len(token) > 100:
            return self.send_json(404, {"error": "Payment link not found."})
        with db_conn() as conn:
            learner = conn.execute("SELECT id, mode FROM learners WHERE billing_token = ?", (token,)).fetchone()
            if not learner:
                return self.send_json(404, {"error": "Payment link not found. Check the link or contact Tutor Club."})
            totals = balance_for(conn, learner["id"])
            charges = allocated_charges(conn, learner["id"])
        return self.send_json(200, {
            "balance_cents": totals["balance_cents"],
            "credit_cents": totals["credit_cents"],
            "charges": [{"label": c["label"], "amount_cents": c["amount_cents"], "balance_cents": c["balance_cents"]}
                        for c in charges if c["balance_cents"] > 0],
            "online_payments_enabled": PAYFAST_ENABLED or DEMO_MODE,
            "demo_mode": DEMO_MODE,
            "provider": "PayFast" if PAYFAST_ENABLED else ("Demo checkout" if DEMO_MODE else None),
        })

    def attempt_quote(self, attempt_id: str) -> None:
        if not re.fullmatch(r"TC-[A-F0-9]{24}", attempt_id):
            return self.send_json(404, {"error": "Payment attempt not found."})
        with db_conn() as conn:
            row = conn.execute("SELECT amount_cents, status FROM payment_attempts WHERE id = ?", (attempt_id,)).fetchone()
        if not row:
            return self.send_json(404, {"error": "Payment attempt not found."})
        return self.send_json(200, {"amount_cents": row["amount_cents"], "status": row["status"], "demo_mode": DEMO_MODE})

    def start_checkout(self) -> None:
        try:
            data = self.read_json()
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        token = data.get("token")
        if not isinstance(token, str) or len(token) < 30 or len(token) > 100:
            return self.send_json(400, {"error": "A valid payment link is required."})
        with db_conn() as conn:
            learner = conn.execute("SELECT * FROM learners WHERE billing_token = ?", (token,)).fetchone()
            if not learner:
                return self.send_json(404, {"error": "Payment link not found."})
            totals = balance_for(conn, learner["id"])
            amount_cents = totals["balance_cents"]
            if amount_cents <= 0:
                return self.send_json(409, {"error": "There is no outstanding balance on this account."})
            provider = "PayFast" if PAYFAST_ENABLED else "Demo"
            attempt_id = new_id()
            created = utc_now()
            conn.execute(
                "INSERT INTO payment_attempts (id, learner_id, amount_cents, provider, status, created_at) VALUES (?, ?, ?, ?, 'pending', ?)",
                (attempt_id, learner["id"], amount_cents, provider, created),
            )
        if PAYFAST_ENABLED:
            if not PUBLIC_BASE_URL.startswith("https://"):
                return self.send_json(503, {"error": "Set a public HTTPS site URL before enabling PayFast."})
            payer_first, payer_last = split_name(learner["contact_name"])
            fields: list[tuple[str, str]] = [
                ("merchant_id", PAYFAST_MERCHANT_ID),
                ("merchant_key", PAYFAST_MERCHANT_KEY),
                ("return_url", f"{PUBLIC_BASE_URL}/payment-return?attempt={urllib.parse.quote(attempt_id)}&token={urllib.parse.quote(token)}"),
                ("cancel_url", f"{PUBLIC_BASE_URL}/pay?token={urllib.parse.quote(token)}&cancelled=1"),
                ("notify_url", f"{PUBLIC_BASE_URL}/api/payfast/itn"),
                ("name_first", payer_first),
                ("name_last", payer_last),
                ("email_address", learner["contact_email"]),
                ("cell_number", learner["contact_phone"]),
                ("m_payment_id", attempt_id),
                ("amount", f"{amount_cents / 100:.2f}"),
                ("item_name", "Tutor Club Mathematics fees"),
                ("item_description", f"{learner['grade']} — {learner['mode']} tuition and outstanding fees"),
            ]
            signature = payfast_signature(fields, PAYFAST_PASSPHRASE)
            fields.append(("signature", signature))
            return self.send_json(200, {
                "mode": "payfast",
                "action": f"{PAYFAST_BASE}/eng/process",
                "fields": [{"name": key, "value": value} for key, value in fields],
            })
        if DEMO_MODE:
            return self.send_json(200, {"mode": "demo", "url": f"/checkout?attempt={urllib.parse.quote(attempt_id)}"})
        return self.send_json(503, {"error": "Online checkout is not configured yet. Please contact Tutor Club to arrange payment."})

    def complete_demo_payment(self) -> None:
        if not DEMO_MODE:
            return self.send_json(404, {"error": "Not found."})
        try:
            data = self.read_json()
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        attempt_id = data.get("attempt")
        if not isinstance(attempt_id, str) or not re.fullmatch(r"TC-[A-F0-9]{24}", attempt_id):
            return self.send_json(400, {"error": "Payment attempt not found."})
        with db_conn() as conn:
            conn.execute("BEGIN IMMEDIATE")
            attempt = conn.execute("SELECT * FROM payment_attempts WHERE id = ?", (attempt_id,)).fetchone()
            if not attempt or attempt["provider"] != "Demo":
                return self.send_json(404, {"error": "Payment attempt not found."})
            if attempt["status"] == "complete":
                return self.send_json(200, {"ok": True, "status": "complete"})
            conn.execute(
                "INSERT OR IGNORE INTO payments (id, learner_id, amount_cents, method, reference, status, created_at, attempt_id) VALUES (?, ?, ?, 'Demo checkout', ?, 'COMPLETE', ?, ?)",
                (new_id("PAY"), attempt["learner_id"], attempt["amount_cents"], attempt_id, utc_now(), attempt_id),
            )
            conn.execute("UPDATE payment_attempts SET status = 'complete' WHERE id = ?", (attempt_id,))
        return self.send_json(200, {"ok": True, "status": "complete"})

    def process_payfast_itn(self) -> None:
        if not PAYFAST_ENABLED:
            return self.send_text(503, "PayFast is not configured.")
        raw = self.parse_body(64_000)
        try:
            pairs = urllib.parse.parse_qsl(raw.decode("utf-8"), keep_blank_values=True, strict_parsing=False)
        except UnicodeDecodeError:
            return self.send_text(400, "Invalid notification.")
        data = dict(pairs)
        signature = data.get("signature", "")
        if not signature or not hmac.compare_digest(payfast_signature(pairs, PAYFAST_PASSPHRASE), signature):
            return self.send_text(400, "Invalid signature.")
        if data.get("merchant_id") != PAYFAST_MERCHANT_ID:
            return self.send_text(400, "Invalid merchant.")
        attempt_id = data.get("m_payment_id", "")
        if not re.fullmatch(r"TC-[A-F0-9]{24}", attempt_id):
            return self.send_text(400, "Unknown payment attempt.")
        # Confirm the notification directly with PayFast before changing a ledger.
        validation_body = urllib.parse.urlencode([(k, v) for k, v in pairs if k != "signature"]).encode("utf-8")
        try:
            request = urllib.request.Request(
                f"{PAYFAST_BASE}/eng/query/validate",
                data=validation_body,
                headers={"Content-Type": "application/x-www-form-urlencoded", "User-Agent": "TutorClub/1.0"},
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=12) as response:
                validation = response.read(256).decode("utf-8", "replace").strip()
        except Exception:
            return self.send_text(503, "Could not confirm notification with PayFast. Retry later.")
        if validation != "VALID":
            return self.send_text(400, "PayFast validation failed.")
        with db_conn() as conn:
            conn.execute("BEGIN IMMEDIATE")
            attempt = conn.execute("SELECT * FROM payment_attempts WHERE id = ?", (attempt_id,)).fetchone()
            if not attempt or attempt["provider"] != "PayFast":
                return self.send_text(404, "Payment attempt not found.")
            if attempt["status"] == "complete":
                return self.send_text(200, "OK")
            try:
                received_cents = int((Decimal(data.get("amount_gross", "0")) * 100).quantize(Decimal("1")))
            except (InvalidOperation, ValueError):
                return self.send_text(400, "Invalid amount.")
            if received_cents != int(attempt["amount_cents"]):
                return self.send_text(400, "Amount mismatch.")
            status = data.get("payment_status", "").upper()
            if status == "COMPLETE":
                conn.execute(
                    "INSERT OR IGNORE INTO payments (id, learner_id, amount_cents, method, reference, status, created_at, attempt_id, gateway_ref) VALUES (?, ?, ?, 'PayFast', ?, 'COMPLETE', ?, ?, ?)",
                    (new_id("PAY"), attempt["learner_id"], attempt["amount_cents"], data.get("pf_payment_id", ""),
                     utc_now(), attempt_id, data.get("pf_payment_id") or attempt_id),
                )
                conn.execute(
                    "UPDATE payment_attempts SET status = 'complete', gateway_payment_id = ? WHERE id = ?",
                    (data.get("pf_payment_id", ""), attempt_id),
                )
            elif status in {"FAILED", "CANCELLED"}:
                conn.execute("UPDATE payment_attempts SET status = 'failed' WHERE id = ?", (attempt_id,))
            else:
                return self.send_text(200, "OK")
        return self.send_text(200, "OK")

    def admin_summary(self) -> None:
        with db_conn() as conn:
            learner_rows = conn.execute("SELECT * FROM learners").fetchall()
            total = len(learner_rows)
            active = sum(1 for row in learner_rows if row["enrollment_status"] == "Active")
            pending = sum(1 for row in learner_rows if row["enrollment_status"] == "Pending")
            month_run_rate = sum(
                ONLINE_MONTHLY_CENTS if row["mode"] == "Online" else FACE_TO_FACE_MONTHLY_CENTS
                for row in learner_rows if row["enrollment_status"] == "Active"
            )
            balances = [learner_summary(conn, row) for row in learner_rows]
            outstanding = sum(item["balance_cents"] for item in balances)
            recent = conn.execute(
                """SELECT p.id, p.amount_cents, p.method, p.reference, p.created_at,
                          l.learner_name, l.grade
                   FROM payments p JOIN learners l ON l.id = p.learner_id
                   WHERE p.status = 'COMPLETE' ORDER BY p.created_at DESC LIMIT 6"""
            ).fetchall()
        return self.send_json(200, {
            "total_learners": total,
            "active_learners": active,
            "pending_learners": pending,
            "monthly_run_rate_cents": month_run_rate,
            "outstanding_cents": outstanding,
            "recent_payments": [dict(r) for r in recent],
        })

    def admin_learners(self, search: str) -> None:
        with db_conn() as conn:
            rows = conn.execute("SELECT * FROM learners ORDER BY created_at DESC").fetchall()
            results = []
            for row in rows:
                data = learner_summary(conn, row)
                if search:
                    haystack = " ".join(str(data.get(k) or "") for k in
                                         ("learner_name", "grade", "mode", "contact_email", "contact_phone", "guardian_name", "id")).casefold()
                    if search not in haystack:
                        continue
                results.append(data)
        return self.send_json(200, {"learners": results})

    def admin_learner_detail(self, learner_id: str) -> None:
        with db_conn() as conn:
            row = conn.execute("SELECT * FROM learners WHERE id = ?", (learner_id,)).fetchone()
            if not row:
                return self.send_json(404, {"error": "Learner record not found."})
            learner = learner_summary(conn, row)
            learner["charges"] = allocated_charges(conn, learner_id)
            learner["payments"] = [dict(p) for p in conn.execute(
                "SELECT id, amount_cents, method, reference, status, created_at FROM payments WHERE learner_id = ? ORDER BY created_at DESC",
                (learner_id,),
            ).fetchall()]
            learner["billing_url"] = f"/pay?token={urllib.parse.quote(row['billing_token'])}"
            learner["payment_attempts"] = [dict(a) for a in conn.execute(
                "SELECT id, amount_cents, provider, status, created_at FROM payment_attempts WHERE learner_id = ? ORDER BY created_at DESC LIMIT 10",
                (learner_id,),
            ).fetchall()]
        return self.send_json(200, learner)

    def admin_payments(self) -> None:
        with db_conn() as conn:
            rows = conn.execute(
                """SELECT p.id, p.amount_cents, p.method, p.reference, p.status, p.created_at,
                          l.id AS learner_id, l.learner_name, l.grade, l.mode
                   FROM payments p JOIN learners l ON l.id = p.learner_id
                   ORDER BY p.created_at DESC LIMIT 200"""
            ).fetchall()
            learners = conn.execute("SELECT * FROM learners ORDER BY created_at DESC").fetchall()
            outstanding = []
            for row in learners:
                data = learner_summary(conn, row)
                if data["balance_cents"] > 0:
                    outstanding.append({"id": data["id"], "learner_name": data["learner_name"],
                                        "grade": data["grade"], "balance_cents": data["balance_cents"],
                                        "payment_status": data["payment_status"]})
        return self.send_json(200, {"payments": [dict(r) for r in rows], "outstanding": outstanding})

    def record_manual_payment(self, learner_id: str) -> None:
        try:
            data = self.read_json()
            amount_cents = cents_from_amount(data.get("amount"))
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        method = clean_text(data.get("method"), 20)
        reference = clean_text(data.get("reference"), 100)
        if method not in {"EFT", "Cash", "Other"}:
            return self.send_json(400, {"error": "Choose EFT, cash or other."})
        with db_conn() as conn:
            conn.execute("BEGIN IMMEDIATE")
            learner = conn.execute("SELECT id FROM learners WHERE id = ?", (learner_id,)).fetchone()
            if not learner:
                return self.send_json(404, {"error": "Learner record not found."})
            due = balance_for(conn, learner_id)["balance_cents"]
            if amount_cents > due:
                return self.send_json(400, {"error": "Payment is greater than the outstanding balance."})
            conn.execute(
                "INSERT INTO payments (id, learner_id, amount_cents, method, reference, status, created_at) VALUES (?, ?, ?, ?, ?, 'COMPLETE', ?)",
                (new_id("PAY"), learner_id, amount_cents, method, reference, utc_now()),
            )
        return self.send_json(201, {"ok": True})

    def add_monthly_charge(self, learner_id: str) -> None:
        try:
            data = self.read_json()
        except ValueError as exc:
            return self.send_json(400, {"error": str(exc)})
        if data.get("confirm") is not True:
            return self.send_json(400, {"error": "Confirm the monthly charge."})
        with db_conn() as conn:
            learner = conn.execute("SELECT mode, enrollment_status FROM learners WHERE id = ?", (learner_id,)).fetchone()
            if not learner:
                return self.send_json(404, {"error": "Learner record not found."})
            if learner["enrollment_status"] == "Withdrawn":
                return self.send_json(400, {"error": "A monthly charge cannot be added to a withdrawn learner."})
            amount = ONLINE_MONTHLY_CENTS if learner["mode"] == "Online" else FACE_TO_FACE_MONTHLY_CENTS
            conn.execute(
                "INSERT INTO charges (id, learner_id, label, amount_cents, created_at) VALUES (?, ?, 'Monthly tuition', ?, ?)",
                (new_id("CHG"), learner_id, amount, utc_now()),
            )
        return self.send_json(201, {"ok": True, "amount_cents": amount})

    def rotate_billing_link(self, learner_id: str) -> None:
        with db_conn() as conn:
            token = new_billing_token()
            cur = conn.execute("UPDATE learners SET billing_token = ? WHERE id = ?", (token, learner_id))
            if cur.rowcount == 0:
                return self.send_json(404, {"error": "Learner record not found."})
        return self.send_json(200, {"ok": True, "billing_url": f"/pay?token={urllib.parse.quote(token)}"})

    def export_csv(self) -> None:
        output = io.StringIO(newline="")
        writer = csv.writer(output)
        writer.writerow(["Learner", "Grade", "Mode", "Age group", "Parent / guardian", "Contact email", "Contact phone",
                         "Enrolment status", "Total charged (ZAR)", "Total paid (ZAR)", "Balance (ZAR)", "Marketing opt-in", "Registered UTC"])
        with db_conn() as conn:
            rows = conn.execute("SELECT * FROM learners ORDER BY created_at DESC").fetchall()
            for row in rows:
                data = learner_summary(conn, row)
                values = [data["learner_name"], data["grade"], data["mode"], "18+" if data["is_adult"] else "Under 18",
                          data["guardian_name"] or "—", data["contact_email"], data["contact_phone"], data["enrollment_status"],
                          f"{data['charged_cents']/100:.2f}", f"{data['paid_cents']/100:.2f}",
                          f"{data['balance_cents']/100:.2f}", "Yes" if data["marketing_opt_in"] else "No", data["created_at"]]
                writer.writerow([csv_safe(v) for v in values])
        body = output.getvalue().encode("utf-8-sig")
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Content-Disposition", 'attachment; filename="tutor-club-learners.csv"')
        self.send_header("Cache-Control", "no-store")
        self.security_headers()
        self.end_headers()
        self.wfile.write(body)


def csv_safe(value: Any) -> Any:
    if isinstance(value, str) and value[:1] in {"=", "+", "-", "@", "\t", "\r"}:
        return "'" + value
    return value


def split_name(name: str) -> tuple[str, str]:
    parts = name.strip().split()
    if len(parts) < 2:
        return (parts[0] if parts else "Tutor Club parent", "")
    return (parts[0], " ".join(parts[1:]))


def main() -> None:
    import argparse
    from http.server import ThreadingHTTPServer

    parser = argparse.ArgumentParser(description="Run the Tutor Club recruitment and payments demo.")
    parser.add_argument("--host", default=os.getenv("HOST", "0.0.0.0"))
    parser.add_argument("--port", type=int, default=int(os.getenv("PORT", "8000")))
    args = parser.parse_args()
    if not ADMIN_PASSWORD:
        raise SystemExit("Set ADMIN_PASSWORD (at least 16 characters) before starting outside demo mode.")
    if not DEMO_MODE and len(ADMIN_PASSWORD) < 16:
        raise SystemExit("ADMIN_PASSWORD must be at least 16 characters outside demo mode.")
    init_db()
    server = __import__("http.server").server.ThreadingHTTPServer((args.host, args.port), TutorClubHandler)
    server.daemon_threads = True
    print(f"Tutor Club running on http://{args.host}:{args.port} | demo_mode={DEMO_MODE} | payfast_enabled={PAYFAST_ENABLED}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
